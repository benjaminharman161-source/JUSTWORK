import { Resource } from "@shared/schema";
import { ExternalLink, Box, Puzzle, BookOpen } from "lucide-react";

const typeIcons = {
  plugin: Puzzle,
  model: Box,
  tutorial: BookOpen,
};

export function ResourceCard({ resource }: { resource: Resource }) {
  const Icon = typeIcons[resource.type as keyof typeof typeIcons] || Box;

  return (
    <div className="group bg-card hover:bg-card/80 border border-border hover:border-primary/50 rounded-xl p-5 transition-all duration-300 shadow-lg hover:shadow-xl hover:-translate-y-1 flex flex-col h-full">
      <div className="flex items-start justify-between mb-4">
        <div className="p-2.5 rounded-lg bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300">
          <Icon className="w-6 h-6" />
        </div>
        <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-secondary text-secondary-foreground border border-white/5 capitalize">
          {resource.category}
        </span>
      </div>
      
      <h3 className="font-display font-bold text-lg text-foreground mb-2 group-hover:text-primary transition-colors">
        {resource.title}
      </h3>
      
      <p className="text-sm text-muted-foreground line-clamp-3 mb-4 flex-grow">
        {resource.description}
      </p>

      <a
        href={resource.url}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex w-full items-center justify-center gap-2 px-4 py-2 rounded-lg bg-secondary hover:bg-white/10 text-sm font-medium text-foreground transition-colors border border-border"
      >
        View Resource <ExternalLink className="w-4 h-4 opacity-50" />
      </a>
    </div>
  );
}
