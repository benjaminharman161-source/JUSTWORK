import { Link, useLocation } from "wouter";
import { LayoutDashboard, MessageSquareCode, Library, Settings, LogOut, Code2 } from "lucide-react";
import { cn } from "@/lib/utils";

export function Navigation() {
  const [location] = useLocation();

  const navItems = [
    { href: "/", icon: LayoutDashboard, label: "Dashboard" },
    { href: "/chat", icon: MessageSquareCode, label: "Script Assistant" },
    { href: "/resources", icon: Library, label: "Resource Library" },
  ];

  return (
    <div className="hidden md:flex flex-col w-64 h-screen bg-card border-r border-border sticky top-0">
      <div className="p-6 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center shadow-lg shadow-primary/20">
          <Code2 className="text-white w-6 h-6" />
        </div>
        <div>
          <h1 className="font-display font-bold text-xl tracking-tight text-white">LuaPilot</h1>
          <p className="text-xs text-muted-foreground font-medium">Roblox Studio Helper</p>
        </div>
      </div>

      <nav className="flex-1 px-4 space-y-2 mt-4">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href} className={cn(
              "flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 group",
              isActive 
                ? "bg-primary/10 text-primary shadow-sm ring-1 ring-primary/20" 
                : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
            )}>
              <item.icon className={cn(
                "w-5 h-5 transition-colors",
                isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground"
              )} />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-border mt-auto">
        <button className="flex w-full items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium text-muted-foreground hover:bg-white/5 hover:text-destructive transition-colors group">
          <LogOut className="w-5 h-5 group-hover:text-destructive transition-colors" />
          Disconnect
        </button>
      </div>
    </div>
  );
}

export function MobileHeader() {
  return (
    <div className="md:hidden h-16 bg-card border-b border-border flex items-center px-4 justify-between sticky top-0 z-50">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
          <Code2 className="text-white w-5 h-5" />
        </div>
        <span className="font-display font-bold text-lg">LuaPilot</span>
      </div>
      {/* Mobile menu trigger would go here */}
    </div>
  );
}
