import { useResources } from "@/hooks/use-resources";
import { useConversations } from "@/hooks/use-chat";
import { Link } from "wouter";
import { ArrowRight, Sparkles, Zap, BookOpen } from "lucide-react";
import { ResourceCard } from "@/components/ResourceCard";
import { motion } from "framer-motion";

export default function Home() {
  const { data: resources, isLoading: loadingResources } = useResources();
  const { data: conversations, isLoading: loadingChats } = useConversations();

  // Get featured/recent resources
  const recentResources = resources?.slice(0, 3) || [];
  const recentChats = conversations?.slice(0, 2) || [];

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto space-y-8">
      {/* Hero Section */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary/20 via-card to-card border border-primary/10 p-8 md:p-12"
      >
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-semibold mb-6 border border-primary/20">
            <Sparkles className="w-3 h-3" />
            <span>AI Powered Lua Assistant</span>
          </div>
          <h1 className="font-display text-4xl md:text-5xl font-bold mb-4 tracking-tight">
            Build better games on <span className="text-primary">Roblox</span> faster.
          </h1>
          <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
            Your intelligent companion for scripting, debugging, and finding the best resources. 
            Stop searching forums and start creating.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/chat" className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-primary text-primary-foreground font-semibold shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5 transition-all duration-200">
              Start Scripting <ArrowRight className="w-4 h-4" />
            </Link>
            <Link href="/resources" className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-secondary text-foreground font-medium hover:bg-secondary/80 border border-white/5 transition-all duration-200">
              Browse Resources
            </Link>
          </div>
        </div>
        
        {/* Background decoration */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />
      </motion.div>

      {/* Stats / Quick Access Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-6 rounded-2xl bg-card border border-border shadow-sm hover:border-primary/50 transition-colors">
          <div className="w-10 h-10 rounded-lg bg-orange-500/10 text-orange-500 flex items-center justify-center mb-4">
            <Zap className="w-5 h-5" />
          </div>
          <h3 className="font-display font-bold text-lg mb-1">Quick Debug</h3>
          <p className="text-sm text-muted-foreground mb-4">Paste your error logs and get instant fixes.</p>
          <Link href="/chat" className="text-sm font-medium text-primary hover:text-primary/80 flex items-center gap-1">
            Open Chat <ArrowRight className="w-3 h-3" />
          </Link>
        </div>

        <div className="p-6 rounded-2xl bg-card border border-border shadow-sm hover:border-primary/50 transition-colors">
          <div className="w-10 h-10 rounded-lg bg-purple-500/10 text-purple-500 flex items-center justify-center mb-4">
            <BookOpen className="w-5 h-5" />
          </div>
          <h3 className="font-display font-bold text-lg mb-1">Documentation</h3>
          <p className="text-sm text-muted-foreground mb-4">Search through API references instantly.</p>
          <Link href="/resources" className="text-sm font-medium text-primary hover:text-primary/80 flex items-center gap-1">
            Search Docs <ArrowRight className="w-3 h-3" />
          </Link>
        </div>

        <div className="p-6 rounded-2xl bg-card border border-border shadow-sm hover:border-primary/50 transition-colors relative overflow-hidden">
          <div className="relative z-10">
            <h3 className="font-display font-bold text-lg mb-2">Recent Chats</h3>
            {loadingChats ? (
              <div className="space-y-2">
                <div className="h-8 bg-white/5 rounded animate-pulse" />
                <div className="h-8 bg-white/5 rounded animate-pulse" />
              </div>
            ) : recentChats.length > 0 ? (
              <div className="space-y-2">
                {recentChats.map(chat => (
                  <Link key={chat.id} href={`/chat?id=${chat.id}`} className="block text-sm text-muted-foreground hover:text-foreground truncate transition-colors">
                    • {chat.title}
                  </Link>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No recent conversations.</p>
            )}
          </div>
        </div>
      </div>

      {/* Featured Resources */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-display text-2xl font-bold">Featured Resources</h2>
          <Link href="/resources" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors">
            View All
          </Link>
        </div>
        
        {loadingResources ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-64 rounded-xl bg-card animate-pulse border border-border" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {recentResources.map(resource => (
              <ResourceCard key={resource.id} resource={resource} />
            ))}
            {recentResources.length === 0 && (
              <div className="col-span-3 text-center py-12 text-muted-foreground bg-card/50 rounded-xl border border-dashed border-border">
                No resources found yet.
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
