import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { useConversations, useConversation, useCreateConversation, useChatStream } from "@/hooks/use-chat";
import { CodeBlock } from "@/components/CodeBlock";
import { Send, Plus, MessageSquare, Loader2, Bot, User } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

export default function Chat() {
  const [location, setLocation] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const activeId = searchParams.get("id") ? parseInt(searchParams.get("id")!) : null;

  const { data: conversations } = useConversations();
  const { data: activeConversation, isLoading: loadingActive } = useConversation(activeId || 0);
  const createConversation = useCreateConversation();
  const { sendMessage, isStreaming, streamedContent } = useChatStream(activeId || 0);

  const [inputValue, setInputValue] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [activeConversation?.messages, streamedContent]);

  const handleCreateNew = async () => {
    const newChat = await createConversation.mutateAsync("New Chat");
    setLocation(`/chat?id=${newChat.id}`);
  };

  const handleSend = async () => {
    if (!inputValue.trim() || !activeId) return;
    
    // If no active chat, create one first? 
    // Ideally we'd have a pending state, but for simplicity we assume user clicked 'new chat' or selected one.
    // However, if we are on /chat without ID, we create one now.
    
    let targetId = activeId;
    if (!targetId) {
       const newChat = await createConversation.mutateAsync(inputValue.slice(0, 30) || "New Chat");
       targetId = newChat.id;
       setLocation(`/chat?id=${targetId}`);
       // We need to wait for redirect/mount before sending? 
       // For better UX, we just reload or let the user re-type. 
       // But let's assume the user selects a chat first for now to keep it simple and robust.
       return; 
    }

    const content = inputValue;
    setInputValue("");
    await sendMessage(content);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Format message content to detect code blocks
  const renderContent = (content: string) => {
    const parts = content.split(/(```[\s\S]*?```)/g);
    return parts.map((part, i) => {
      if (part.startsWith("```")) {
        const match = part.match(/```(\w*)\n([\s\S]*?)```/);
        const language = match ? match[1] : "lua";
        const code = match ? match[2] : part.slice(3, -3);
        return <CodeBlock key={i} code={code} language={language || "lua"} />;
      }
      return <span key={i} className="whitespace-pre-wrap">{part}</span>;
    });
  };

  return (
    <div className="flex h-[calc(100vh-4rem)] md:h-screen overflow-hidden">
      {/* Sidebar List */}
      <div className="w-80 border-r border-border bg-card/50 flex flex-col hidden lg:flex">
        <div className="p-4 border-b border-border">
          <button
            onClick={handleCreateNew}
            disabled={createConversation.isPending}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-all disabled:opacity-50"
          >
            {createConversation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
            New Chat
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {conversations?.map((chat) => (
            <button
              key={chat.id}
              onClick={() => setLocation(`/chat?id=${chat.id}`)}
              className={cn(
                "w-full text-left px-4 py-3 rounded-lg text-sm font-medium transition-colors flex items-center gap-3",
                activeId === chat.id 
                  ? "bg-primary/10 text-primary" 
                  : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
              )}
            >
              <MessageSquare className="w-4 h-4 shrink-0" />
              <span className="truncate">{chat.title}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col bg-background relative">
        {!activeId ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
            <div className="w-20 h-20 rounded-2xl bg-primary/10 flex items-center justify-center mb-6">
              <Bot className="w-10 h-10 text-primary" />
            </div>
            <h2 className="font-display text-2xl font-bold mb-2">Select a conversation</h2>
            <p className="text-muted-foreground max-w-md mb-8">
              Choose a chat from the sidebar or start a new one to begin debugging your Roblox scripts.
            </p>
            <button
              onClick={handleCreateNew}
              className="px-6 py-3 rounded-xl bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-all"
            >
              Start New Chat
            </button>
          </div>
        ) : (
          <>
            {/* Messages */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6">
              {loadingActive ? (
                <div className="flex justify-center p-8">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                </div>
              ) : (
                <>
                  {activeConversation?.messages.map((msg) => (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      key={msg.id}
                      className={cn(
                        "flex gap-4 max-w-4xl mx-auto",
                        msg.role === "user" ? "justify-end" : "justify-start"
                      )}
                    >
                      {msg.role === "assistant" && (
                        <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 mt-1">
                          <Bot className="w-5 h-5 text-primary" />
                        </div>
                      )}
                      
                      <div className={cn(
                        "rounded-2xl p-4 md:p-5 text-sm md:text-base leading-relaxed shadow-sm max-w-[85%]",
                        msg.role === "user" 
                          ? "bg-primary text-primary-foreground rounded-tr-none" 
                          : "bg-card border border-border rounded-tl-none"
                      )}>
                        {renderContent(msg.content)}
                      </div>

                      {msg.role === "user" && (
                        <div className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center shrink-0 mt-1">
                          <User className="w-5 h-5 text-muted-foreground" />
                        </div>
                      )}
                    </motion.div>
                  ))}

                  {/* Streaming Message Bubble */}
                  {isStreaming && (
                    <div className="flex gap-4 max-w-4xl mx-auto justify-start">
                       <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 mt-1">
                          <Bot className="w-5 h-5 text-primary" />
                        </div>
                        <div className="bg-card border border-border rounded-2xl rounded-tl-none p-4 md:p-5 text-sm md:text-base leading-relaxed shadow-sm max-w-[85%]">
                          {renderContent(streamedContent)}
                          <span className="inline-block w-2 h-4 ml-1 align-middle bg-primary animate-pulse" />
                        </div>
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Input Area */}
            <div className="p-4 md:p-6 bg-card border-t border-border">
              <div className="max-w-4xl mx-auto relative">
                <textarea
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Ask about your Lua script..."
                  className="w-full bg-background border border-border rounded-xl px-4 py-3 pr-14 min-h-[60px] max-h-[200px] resize-none focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 transition-all text-sm md:text-base"
                  disabled={isStreaming}
                />
                <button
                  onClick={handleSend}
                  disabled={!inputValue.trim() || isStreaming}
                  className="absolute right-2 bottom-2 p-2 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 disabled:bg-muted disabled:text-muted-foreground transition-all"
                >
                  {isStreaming ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                </button>
              </div>
              <p className="text-center text-xs text-muted-foreground mt-2">
                LuaPilot can make mistakes. Verify code before running in production.
              </p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
