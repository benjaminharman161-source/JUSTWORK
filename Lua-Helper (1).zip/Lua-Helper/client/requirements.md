## Packages
prismjs | Syntax highlighting for code blocks (Lua support)
framer-motion | Smooth animations for chat bubbles and page transitions
lucide-react | Icons (already in base, but ensuring it's noted)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
  mono: ["var(--font-mono)"],
}
Chat streaming requires handling SSE (Server-Sent Events) manually or via a helper hook, as standard fetch doesn't stream.
Resources API is read-only for the frontend (list/get).
Image uploads: The chat interface now supports base64 image data in the POST /api/conversations/:id/messages request as 'imageUrl'.
