import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { registerChatRoutes } from "./replit_integrations/chat";
import { registerImageRoutes } from "./replit_integrations/image";
import { api } from "@shared/routes";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Register integration routes
  registerChatRoutes(app);
  registerImageRoutes(app);

  // Resources API
  app.get(api.resources.list.path, async (req, res) => {
    const resources = await storage.getResources();
    res.json(resources);
  });

  app.get(api.resources.get.path, async (req, res) => {
    const resource = await storage.getResource(Number(req.params.id));
    if (!resource) {
      return res.status(404).json({ message: "Resource not found" });
    }
    res.json(resource);
  });

  // Seed data check
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const existing = await storage.getResources();
  if (existing.length === 0) {
    console.log("Seeding database with resources...");
    
    await storage.createResource({
      title: "Roblox API Reference",
      description: "Official documentation for all Roblox classes, data types, and enums.",
      url: "https://create.roblox.com/docs/reference/engine",
      type: "documentation",
      category: "scripting",
      imageUrl: "https://create.roblox.com/assets/images/roblox-studio-logo.png"
    });

    await storage.createResource({
      title: "Lua 5.1 Manual",
      description: "The official manual for Lua 5.1, the version used by Roblox.",
      url: "https://www.lua.org/manual/5.1/",
      type: "documentation",
      category: "scripting",
      imageUrl: "https://www.lua.org/images/lua-logo.gif"
    });

    await storage.createResource({
      title: "Moon Animator 2",
      description: "A powerful animation plugin for Roblox Studio.",
      url: "https://www.roblox.com/library/4725618216/Moon-Animator-2",
      type: "plugin",
      category: "animation",
      imageUrl: "https://tr.rbxcdn.com/0f6b4b4e5b5e5b5e5b5e5b5e5b5e5b5e/150/150/Image/Png"
    });

    await storage.createResource({
      title: "Tag Editor",
      description: "Essential plugin for managing CollectionService tags.",
      url: "https://www.roblox.com/library/948084095/Tag-Editor",
      type: "plugin",
      category: "utility",
      imageUrl: "https://tr.rbxcdn.com/1f6b4b4e5b5e5b5e5b5e5b5e5b5e5b5e/150/150/Image/Png"
    });
    
    await storage.createResource({
      title: "Chickynoid",
      description: "Server-authoritative movement framework for Roblox.",
      url: "https://github.com/EasyGamesOfficial/Chickynoid",
      type: "model",
      category: "networking",
      imageUrl: "https://avatars.githubusercontent.com/u/85474640?s=200&v=4"
    });
  }
}
