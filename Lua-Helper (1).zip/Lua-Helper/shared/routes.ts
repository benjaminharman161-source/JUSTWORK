import { z } from 'zod';
import { insertResourceSchema, resources } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  resources: {
    list: {
      method: 'GET' as const,
      path: '/api/resources' as const,
      responses: {
        200: z.array(z.custom<typeof resources.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/resources/:id' as const,
      responses: {
        200: z.custom<typeof resources.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
  // Note: Chat routes are handled by the integration at /api/conversations/*
  // We document them here for the frontend to be aware, even if not strictly used by Zod in the same way
  chat: {
    conversations: {
      list: {
        method: 'GET' as const,
        path: '/api/conversations' as const,
      },
      create: {
        method: 'POST' as const,
        path: '/api/conversations' as const,
      },
      messages: {
        create: {
          method: 'POST' as const,
          path: '/api/conversations/:id/messages' as const,
        }
      }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
